const menudownload = (prefix) => {

return `
╭━━━━━•𖧹❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ👑❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ𖧹•━━━━━╮
┃  ༺⁖ฺ᠂DOWNLOADS▧⃯⃟৴ํ͘🤴
┠━━━━━•𖧹❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ🌹❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ𖧹•━━━━━╯
┠ৎ✿【🔊】${prefix}Play
┠ৎ✿【🔉】${prefix}Play2
┠ৎ✿【📼】${prefix}Playmp4
┠ৎ✿【📤】${prefix}Playdoc
┠ৎ✿【💽】${prefix}Playmix
┠ৎ✿【📣】${prefix}Play_audio
┠ৎ✿【📼】${prefix}Play_video
┠ৎ✿【🦸‍♂️】${prefix}Shazam
┠ৎ✿【🎶】${prefix}Spotify
┠ৎ✿【🎵】${prefix}tiktok
┠ৎ✿【🎵】${prefix}tiktokimg
┠ৎ✿【👂】${prefix}Tiktokaudio
┠ৎ✿【🧑‍🏫】${prefix}Instagram 
┠ৎ✿【🗣️】${prefix}Instaaudio
┠ৎ✿【🎭】${prefix}Instafoto
┠ৎ✿【🌚】${prefix}Deezer
┠ৎ✿【🔋】${prefix}Soundcloud
┠ৎ✿【🚀】${prefix}audiomeme
┠ৎ✿【🚀】${prefix}audiomeme2
┠━━━━━◉
┠ৎ 📌-Downloads
╰━━━━━•𖧹❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ🎋❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ𖧹•━━━━━╯`
}

module.exports = menudownload