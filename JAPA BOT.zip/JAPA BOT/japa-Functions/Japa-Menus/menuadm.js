const menuadm = (prefix) => {

return `
​╭━━━━━•𖧹❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ👑❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ𖧹•━━━━━╮
┃ ༺⁖ฺ۟̇࣪MENU -᠂ADMINS▧⃯⃟৴ํ͘🤴
┠━━━━━•𖧹❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ🌹❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ𖧹•━━━━━╯
┠ৎ✿【📸】${prefix}Antiimg (1/0)
┠ৎ✿【📼】${prefix}Antivideo (1/0)
┠ৎ✿【🎤】${prefix}Antiaudio (1/0)
┠ৎ✿【🖍️】${prefix}Antisticker (1/0)
┠ৎ✿【🔗】${prefix}Antilinkgp (1/0)
┠ৎ✿【🔗】${prefix}Antilinkhard (1/0)
┠ৎ✿【💂】${prefix}Antifake (1/0)
┠ৎ✿【🔠】${prefix}Limitecaracteres (1/0)
┠ৎ✿【🌚】${prefix}Bemvindo (1/0)
┠ৎ✿【🌝】${prefix}Bemvindo2 (1/0)
┠ৎ✿【🤖】${prefix}Simih (1/0)
┠ৎ✿【🤖】${prefix}Simih2 (1/0)
┠ৎ✿【🖍️】${prefix}Autosticker (1/0)
┠ৎ✿【🌐】${prefix}Autorepo (1/0)
┠ৎ✿【🥸】${prefix}Leveling (1/0)
┠ৎ✿【🔞】${prefix}Modonsfw (1/0)
┠ৎ✿【❕】${prefix}Odelete (1/0)
┠ৎ✿【👁️】${prefix}x9visuunica (1/0)
┠ৎ✿【📢】${prefix}x9 (1/0)
┠ৎ✿【🔠】${prefix}Legenda_imagem (Texto)
┠ৎ✿【🪬】${prefix}Legenda_video (Texto)
┠ৎ✿【🧾】${prefix}Legenda_estrangeiro (Texto)
┠ৎ✿【🔉】${prefix}Legendabv (Texto)
┠ৎ✿【🏃】${prefix}Legendasaiu (Texto)
┠ৎ✿【🔈】${prefix}Legendabv2 (Texto)
┠ৎ✿【💨】${prefix}Legendasaiu2 (Texto)
┠ৎ✿【🤴】${prefix}So_adm
┠ৎ✿【🔢】${prefix}Requestgp -list
┠ৎ✿【⏲️】${prefix}Requestgp -a numero
┠ৎ✿【📝】${prefix}Requestgp -r numero
┠ৎ✿【🔐】${prefix}Fechar-gp
┠ৎ✿【📋】${prefix}Listanegra (Número)
┠ৎ✿【🚧】${prefix}Tirardalista (Número)
┠ৎ✿【📋】${prefix}ListanegraG (Número)
┠ৎ✿【🚧】${prefix}TirardalistaG (Número)
┠ৎ✿【🔢】${prefix}Multiprefixo (1/0)
┠ৎ✿【➕】${prefix}Add_prefixo
┠ৎ✿【➖】${prefix}Tirar_prefixo
┠ৎ✿【📥】${prefix}Banghost
┠ৎ✿【🔇】${prefix}Mute (@mencionar)
┠ৎ✿【💬】${prefix}Desmute (@mencionar)
┠ৎ✿【🚯】${prefix}Kick [@] (Para-remover) 
┠ৎ✿【🚷】${prefix}Ban (Responder-mensagem)
┠ৎ✿【👑】${prefix}Promover [@] (Ser-admin)
┠ৎ✿【👤】${prefix}Rebaixar [@] (Rebaixar-adm)
┠ৎ✿【🗯️】${prefix}Changegroup (all/adms)
┠ৎ✿【🗨️】${prefix}Rmphotogp (Remover ft do gp)
┠ৎ✿【💭】${prefix}Ephemeral [1/0] (Msg-temp)
┠ৎ✿【💬】${prefix}Descgp (Texto)
┠ৎ✿【🏷️】${prefix}Nomegp (Nome)
┠ৎ✿【🔖】${prefix}Totag (Mencionar algo)
┠ৎ✿【🔏】${prefix}Grupo (f/a)
┠ৎ✿【🗒️】${prefix}Status
┠ৎ✿【🚮】${prefix}Limpar (texto-invisível-gp)
┠ৎ✿【🤹‍♂️】${prefix}Atividades (DO-GRUPO)
┠ৎ✿【🔗】${prefix}Linkgp
┠ৎ✿【💾】${prefix}Grupoinfo
┠ৎ✿【⏲️】${prefix}Hidetag (txt) (marcação)
┠ৎ✿【👤】${prefix}Marcar (marca tds do gp)
┠ৎ✿【👥】${prefix}Marcar2 (Marca-tds-wa.me)
┠ৎ✿【📃】${prefix}Anagrama (1/0)
┠ৎ✿【📄】${prefix}Antipalavra (1/0)
┠ৎ✿【🗄️】${prefix}Criartabela (Escreva-algo)
┠ৎ✿【🗃️】${prefix}Tabelagp (Veja a tabela)
┠ৎ✿【🕦】${prefix}Fechargp
┠ৎ✿【🕦】${prefix}Abrirgp

┠━━━━━◉
┠ৎ 👑-Admins
╰━━━━━•𖧹❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ🎋❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ𖧹•━━━━━╯`
}

module.exports = menuadm