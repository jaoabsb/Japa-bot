const menupesquisas = (prefix) => {

// By: SCHOTWRD

return `
╭━━━━━•𖧹❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ👑❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ𖧹•━━━━━╮
┃   ༺⁖ฺ᠂𝐌𝐞𝐧𝐮 𝐏𝐞𝐬𝐪𝐮𝐢𝐬𝐚𝐬▧⃯⃟৴ํ͘
┠━━━━━•𖧹❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ🌹❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ𖧹•━━━━━╯
┠ৎ✿【🔎】${prefix}Gpt (duvida)
┠ৎ✿【🔎】${prefix}Bing (duvida)
┠ৎ✿【🔎】${prefix}Criarimg
┠ৎ✿【🔎】${prefix}Pinterest
┠ৎ✿【🔎】${prefix}Gitclone
┠ৎ✿【🔎】${prefix}euro
┠ৎ✿【🔎】${prefix}dolar
┠ৎ✿【🔎】${prefix}bitcoin
┠ৎ✿【🔎】${prefix}ethereum
┠ৎ✿【🔎】${prefix}libra
┠ৎ✿【🔍】${prefix}Manga
┠ৎ✿【🔍】${prefix}Memes
┠ৎ✿【🔍】${prefix}Enquete
┠━━━━━◉
┠ৎ ↗️-Pesquisas
╰━━━━━•𖧹❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ🎋❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ𖧹•━━━━━╯`
}

module.exports = menupesquisas