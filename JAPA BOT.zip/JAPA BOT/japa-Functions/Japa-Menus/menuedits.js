const menuedits = (prefix) => {

// By: JAPA

return `
╭━━━━━◉╭━━━━━•𖧹❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ👑❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ𖧹•━━━━━╮
┃  ༺⁖ฺ۟̇࣪ANIMES - EDITS ⃝༘⃕🍒 
┠━━━━━•𖧹❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ🌹❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ𖧹•━━━━━╯
┠ৎ✿【🎉】${prefix}Editanime -random
┠ৎ✿【🎉】${prefix}Editanime -bleach
┠ৎ✿【🎉】${prefix}Editanime -chainsaw
┠ৎ✿【🎉】${prefix}Editanime -dragonball
┠ৎ✿【🎉】${prefix}Editanime -kimetsu
┠ৎ✿【🎉】${prefix}Editanime -jujutsu
┠ৎ✿【🎉】${prefix}Editanime -naruto

⿴⃟ٍࣽ❯❯   ANIMES - IMAGEM   ❮❮⃟ٍࣽ⿴

┠ৎ✿【🚀】${prefix}Animeimg -cosplay
┠ৎ✿【🚀】${prefix}Animeimg -waify
┠ৎ✿【🚀】${prefix}Animeimg -loli
┠ৎ✿【🚀】${prefix}Animeimg -shota
┠ৎ✿【🚀】${prefix}Animeimg -shinomiya
┠ৎ✿【🚀】${prefix}Animeimg -yotsuba
┠ৎ✿【🚀】${prefix}Animeimg -yumeko
┠ৎ✿【🚀】${prefix}Animeimg -tejina
┠ৎ✿【🚀】${prefix}Animeimg -chiho
┠ৎ✿【🚀】${prefix}Animeimg -kaori
┠ৎ✿【🚀】${prefix}Animeimg -boruto
┠ৎ✿【🚀】${prefix}Animeimg -shizuka
┠ৎ✿【🚀】${prefix}Animeimg -kaga
┠ৎ✿【🚀】${prefix}Animeimg -kotori
┠ৎ✿【🚀】${prefix}Animeimg -mikasa
┠ৎ✿【🚀】${prefix}Animeimg -akiyama
┠ৎ✿【🚀】${prefix}Animeimg -gremory
┠ৎ✿【🚀】${prefix}Animeimg -izuku
┠ৎ✿【🚀】${prefix}Animeimg -shina
┠ৎ✿【🚀】${prefix}Animeimg -shinka
┠ৎ✿【🚀】${prefix}Animeimg -yuri
┠ৎ✿【🚀】${prefix}Animeimg -eba
┠ৎ✿【🚀】${prefix}Animeimg -erza
┠ৎ✿【🚀】${prefix}Animeimg -elaina
┠ৎ✿【🚀】${prefix}Animeimg -hinata
┠ৎ✿【🚀】${prefix}Animeimg -naruto
┠ৎ✿【🚀】${prefix}Animeimg -minato
┠ৎ✿【🚀】${prefix}Animeimg -sagari
┠ৎ✿【🚀】${prefix}Animeimg -nezuko
┠ৎ✿【🚀】${prefix}Animeimg -rize
┠ৎ✿【🚀】${prefix}Animeimg -anna
┠ৎ✿【🚀】${prefix}Animeimg -deidara
┠ৎ✿【🚀】${prefix}Animeimg -asuna
┠ৎ✿【🚀】${prefix}Animeimg -ayuzawa
┠ৎ✿【🚀】${prefix}Animeimg -emilia 
┠ৎ✿【🚀】${prefix}Animeimg -inori
┠ৎ✿【🚀】${prefix}Animeimg -hestia
┠ৎ✿【🚀】${prefix}Animeimg -chitoge
┠ৎ✿【🚀】${prefix}Animeimg -itachi
┠ৎ✿【🚀】${prefix}Animeimg -madara
┠ৎ✿【🚀】${prefix}Animeimg -sakura
┠ৎ✿【🚀】${prefix}Animeimg -sasuke
┠ৎ✿【🚀】${prefix}Animeimg -tsunade
┠ৎ✿【🚀】${prefix}Animeimg -onepiece
┠ৎ✿【🚀】${prefix}Animeimg -mobil
┠ৎ✿【🚀】${prefix}Animeimg -montor
┠ৎ✿【🚀】${prefix}Animeimg -keneki
┠ৎ✿【🚀】${prefix}Animeimg -megumin
┠ৎ✿【🚀】${prefix}Animeimg -toukachan
┠━━━━━◉
┠ৎ 🤹-Animação
╰━━━━━•𖧹❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ🎋❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ𖧹•━━━━━╯`
}

module.exports = menuedits