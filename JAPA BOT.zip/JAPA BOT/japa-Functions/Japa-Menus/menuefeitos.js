const menuefeitos = (prefix) => {

return `
╭━━━━━•𖧹❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ👑❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ𖧹•━━━━━╮
┃  ༺⁖ฺ۟̇࣪MENU -᠂EFEITOS ⃝༘⃕🥸 
┠━━━━━•𖧹❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ🌹❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ𖧹•━━━━━╯
┠ৎ✿【🎊】${prefix}Comunisco 
┠ৎ✿【🪅】${prefix}Bolsonaro 
┠ৎ✿【🎊】${prefix}Bnw 
┠ৎ✿【🪅】${prefix}Beautiful 
┠ৎ✿【🎊】${prefix}Blur 
┠ৎ✿【🪅】${prefix}Affect 
┠ৎ✿【🎊】${prefix}Del 
┠ৎ✿【🪅】${prefix}Circle 
┠ৎ✿【🎊】${prefix}Dither 
┠ৎ✿【🪅】${prefix}Facepalm 
┠ৎ✿【🎊】${prefix}Invert 
┠ৎ✿【🪅】${prefix}Lgbt 
┠ৎ✿【🎊】${prefix}Magik 
┠ৎ✿【🪅】${prefix}Rotate 
┠ৎ✿【🎊】${prefix}Rip 
┠ৎ✿【🪅】${prefix}Jail 
┠ৎ✿【🎊】${prefix}Trash 
┠ৎ✿【🪅】${prefix}Pixelate 
┠ৎ✿【🎊】${prefix}Sepia 
┠ৎ✿【🪅】${prefix}Wanted 
┠ৎ✿【🎊】${prefix}Wasted 
┠ৎ✿【🪅】${prefix}Animeia 
┠━━━━━◉
┠ৎ🌟 Marque uma imagem
╰━━━━━•𖧹❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ🎋❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ𖧹•━━━━━╯`
}

module.exports = menuefeitos