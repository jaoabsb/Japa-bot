const menualteradores = (prefix) => {


// By: JAPA

return`
╭━━━━━•𖧹❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ👑❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ𖧹•━━━━━╮
┃   ༺⁖ฺ۟̇࣪ALTERADORES〬 °⃟᮪݇⃟⃟🔋
┠━━━━━•𖧹❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ🌹❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ𖧹•━━━━━╯
⿴⃟ٍࣽ❯❯   ALTERAÇÃO DE VÍDEO   ❮❮⃟ٍࣽ⿴

┠ৎ✿【📼】${prefix}Videolento (marca)
┠ৎ✿【📼】${prefix}Videorapido (marca)
┠ৎ✿【📼】${prefix}Videocontrario (marca)

⿴⃟ٍࣽ❯❯   ALTERAÇÃO DE ÁUDIO   ❮❮⃟ٍࣽ⿴

┠ৎ✿【💽】${prefix}Audiolento (marca)
┠ৎ✿【💽】${prefix}Audiorapido (marca)
┠ৎ✿【💽】${prefix}Grave (marca)
┠ৎ✿【💽】${prefix}Grave2 (marca)
┠ৎ✿【💽】${prefix}Esquilo (marca)
┠ৎ✿【💽】${prefix}Estourar (marca)
┠ৎ✿【💽】${prefix}Bass (marca)
┠ৎ✿【💽】${prefix}Bass2 (marca)
┠ৎ✿【💽】${prefix}Vozmenino (marca)

⿴⃟ٍࣽ❯❯   OPÇÕES DE DUBLAGEM   ❮❮⃟ٍࣽ⿴

┠ৎ✿【🗣️】 ${prefix}Mickey (seu texto)
┠ৎ✿【🗣️】 ${prefix}Faustao (seu texto)
┠ৎ✿【🗣️】 ${prefix}Eminem (seu texto)
┠ৎ✿【🗣️】 ${prefix}Chapolin (seu texto)
┠ৎ✿【🗣️】 ${prefix}Ibere (seu texto)
┠━━━━━◉
┠ৎ 🗄️-voz effects
╰━━━━━•𖧹❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ🎤❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ𖧹•━━━━━╯`
}

module.exports = menualteradores