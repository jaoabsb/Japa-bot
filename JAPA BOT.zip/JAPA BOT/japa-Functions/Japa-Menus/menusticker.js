const menusticker = (prefix) => {

// By: SCHOTWRD

return `
╭━━━━━•𖧹❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ👑❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ𖧹•━━━━━╮
┃ ༺⁖ฺ۟̇࣪MENU - STICKE᠂࣭R.S ⃝༘⃕🍒 
┠━━━━━•𖧹❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ🌹❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ𖧹•━━━━━╯
┠ৎ✿【🤯】${prefix}Ttp (Seu texto)
┠ৎ✿【🫨】${prefix}Fsticker (Marcar-foto)
┠ৎ✿【🤫】${prefix}Sticker (Marcar-foto)
┠ৎ✿【😙】${prefix}Toimg (Marcar-sticker)
┠ৎ✿【😆】${prefix}Attp (Seu texto)
┠ৎ✿【🤭】${prefix}Togif (Marcar-sticker)
┠ৎ✿【🤑】${prefix}Roubar (Texto/Texto)
┠ৎ✿【😈】${prefix}Figurinhas (Quantidade)
┠ৎ✿【👻】${prefix}Figumemes (Quantidade)
┠ৎ✿【🤓】${prefix}Figuflork (Quantidade)
┠ৎ✿【🌝】${prefix}Figuemoji (Quantidade)
┠ৎ✿【🎃】${prefix}Figucoreana (Quantidade)
┠ৎ✿【😷】${prefix}Figubebe (Quantidade)
┠ৎ✿【😳】${prefix}Figuanime (Quantidade)
┠ৎ✿【🤡】${prefix}Figufunny (Quantidade)
┠ৎ✿【🧐】${prefix}Figuanimais (Quantidade)
┠ৎ✿【😤】${prefix}Figudesenho (Quantidade)
┠ৎ✿【🙄】${prefix}Figuraiva (Quantidade)
┠ৎ✿【🤐】${prefix}Figuroblox (Quantidade)
┠ৎ✿【😸】${prefix}Qc (Mensagem desejada)
┠ৎ✿【🤪】${prefix}Buscar_stk (Nome)
┠ৎ✿【😬】${prefix}Figaleatoria
┠━━━━━◉
┠ৎ 🤡-Entretenimento
╰━━━━━•𖧹❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ🎋❀⃘࣭࣭࣭࣭ٜꔷ⃔໑࣭࣭ٜ𖧹•━━━━━╯`
}

module.exports = menusticker