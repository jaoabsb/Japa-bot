# PixAPI-MercadoPago-Js
Sistema de criar e conferir pagamentos via pix com a API do Mercado Pago.
